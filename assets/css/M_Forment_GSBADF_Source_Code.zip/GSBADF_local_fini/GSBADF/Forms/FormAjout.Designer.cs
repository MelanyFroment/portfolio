﻿namespace GSBADF.Forms
{
    partial class FormAjout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTitre = new System.Windows.Forms.TextBox();
            this.txtCom = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCom = new System.Windows.Forms.Label();
            this.txtHT = new System.Windows.Forms.TextBox();
            this.lblHT = new System.Windows.Forms.Label();
            this.lblTVA = new System.Windows.Forms.Label();
            this.lblTTC = new System.Windows.Forms.Label();
            this.txtTVA = new System.Windows.Forms.TextBox();
            this.txtTTC = new System.Windows.Forms.TextBox();
            this.btnValid = new System.Windows.Forms.Button();
            this.txtTitlePrinc = new System.Windows.Forms.Label();
            this.txtPaiementType = new System.Windows.Forms.TextBox();
            this.lblPaimentType = new System.Windows.Forms.Label();
            this.txtPaiementCom = new System.Windows.Forms.TextBox();
            this.lblPaimentCommentaire = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtTitre
            // 
            this.txtTitre.Location = new System.Drawing.Point(302, 80);
            this.txtTitre.Name = "txtTitre";
            this.txtTitre.Size = new System.Drawing.Size(273, 22);
            this.txtTitre.TabIndex = 1;
            // 
            // txtCom
            // 
            this.txtCom.Location = new System.Drawing.Point(302, 130);
            this.txtCom.Name = "txtCom";
            this.txtCom.Size = new System.Drawing.Size(273, 22);
            this.txtCom.TabIndex = 2;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(182, 80);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(34, 16);
            this.lblTitle.TabIndex = 4;
            this.lblTitle.Text = "Titre";
            // 
            // lblCom
            // 
            this.lblCom.AutoSize = true;
            this.lblCom.Location = new System.Drawing.Point(182, 136);
            this.lblCom.Name = "lblCom";
            this.lblCom.Size = new System.Drawing.Size(87, 16);
            this.lblCom.TabIndex = 5;
            this.lblCom.Text = "Commentaire";
            // 
            // txtHT
            // 
            this.txtHT.Location = new System.Drawing.Point(302, 181);
            this.txtHT.Name = "txtHT";
            this.txtHT.Size = new System.Drawing.Size(273, 22);
            this.txtHT.TabIndex = 6;
            // 
            // lblHT
            // 
            this.lblHT.AutoSize = true;
            this.lblHT.Location = new System.Drawing.Point(182, 187);
            this.lblHT.Name = "lblHT";
            this.lblHT.Size = new System.Drawing.Size(76, 16);
            this.lblHT.TabIndex = 7;
            this.lblHT.Text = "Montant HT";
            // 
            // lblTVA
            // 
            this.lblTVA.AutoSize = true;
            this.lblTVA.Location = new System.Drawing.Point(182, 238);
            this.lblTVA.Name = "lblTVA";
            this.lblTVA.Size = new System.Drawing.Size(84, 16);
            this.lblTVA.TabIndex = 8;
            this.lblTVA.Text = "Montant TVA";
            // 
            // lblTTC
            // 
            this.lblTTC.AutoSize = true;
            this.lblTTC.Location = new System.Drawing.Point(182, 287);
            this.lblTTC.Name = "lblTTC";
            this.lblTTC.Size = new System.Drawing.Size(84, 16);
            this.lblTTC.TabIndex = 9;
            this.lblTTC.Text = "Montant TTC";
            // 
            // txtTVA
            // 
            this.txtTVA.Location = new System.Drawing.Point(302, 232);
            this.txtTVA.Name = "txtTVA";
            this.txtTVA.Size = new System.Drawing.Size(273, 22);
            this.txtTVA.TabIndex = 10;
            // 
            // txtTTC
            // 
            this.txtTTC.Location = new System.Drawing.Point(302, 281);
            this.txtTTC.Name = "txtTTC";
            this.txtTTC.Size = new System.Drawing.Size(273, 22);
            this.txtTTC.TabIndex = 11;
            // 
            // btnValid
            // 
            this.btnValid.Location = new System.Drawing.Point(588, 434);
            this.btnValid.Name = "btnValid";
            this.btnValid.Size = new System.Drawing.Size(100, 31);
            this.btnValid.TabIndex = 12;
            this.btnValid.Text = "Valider";
            this.btnValid.UseVisualStyleBackColor = true;
            this.btnValid.Click += new System.EventHandler(this.BtnValid_Click);
            // 
            // txtTitlePrinc
            // 
            this.txtTitlePrinc.AutoSize = true;
            this.txtTitlePrinc.Location = new System.Drawing.Point(353, 25);
            this.txtTitlePrinc.Name = "txtTitlePrinc";
            this.txtTitlePrinc.Size = new System.Drawing.Size(151, 16);
            this.txtTitlePrinc.TabIndex = 13;
            this.txtTitlePrinc.Text = "Information note de frais ";
            // 
            // txtPaiementType
            // 
            this.txtPaiementType.Location = new System.Drawing.Point(302, 331);
            this.txtPaiementType.Name = "txtPaiementType";
            this.txtPaiementType.Size = new System.Drawing.Size(273, 22);
            this.txtPaiementType.TabIndex = 14;
            // 
            // lblPaimentType
            // 
            this.lblPaimentType.AutoSize = true;
            this.lblPaimentType.Location = new System.Drawing.Point(182, 337);
            this.lblPaimentType.Name = "lblPaimentType";
            this.lblPaimentType.Size = new System.Drawing.Size(91, 16);
            this.lblPaimentType.TabIndex = 15;
            this.lblPaimentType.Text = "Paiment Type";
            // 
            // txtPaiementCom
            // 
            this.txtPaiementCom.Location = new System.Drawing.Point(302, 383);
            this.txtPaiementCom.Name = "txtPaiementCom";
            this.txtPaiementCom.Size = new System.Drawing.Size(273, 22);
            this.txtPaiementCom.TabIndex = 16;
            // 
            // lblPaimentCommentaire
            // 
            this.lblPaimentCommentaire.AutoSize = true;
            this.lblPaimentCommentaire.Location = new System.Drawing.Point(134, 389);
            this.lblPaimentCommentaire.Name = "lblPaimentCommentaire";
            this.lblPaimentCommentaire.Size = new System.Drawing.Size(139, 16);
            this.lblPaimentCommentaire.TabIndex = 17;
            this.lblPaimentCommentaire.Text = "Paiment Commentaire";
            // 
            // FormAjout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 564);
            this.Controls.Add(this.lblPaimentCommentaire);
            this.Controls.Add(this.txtPaiementCom);
            this.Controls.Add(this.lblPaimentType);
            this.Controls.Add(this.txtPaiementType);
            this.Controls.Add(this.txtTitlePrinc);
            this.Controls.Add(this.btnValid);
            this.Controls.Add(this.txtTTC);
            this.Controls.Add(this.txtTVA);
            this.Controls.Add(this.lblTTC);
            this.Controls.Add(this.lblTVA);
            this.Controls.Add(this.lblHT);
            this.Controls.Add(this.txtHT);
            this.Controls.Add(this.lblCom);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtCom);
            this.Controls.Add(this.txtTitre);
            this.Name = "FormAjout";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtTitre;
        private System.Windows.Forms.TextBox txtCom;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblCom;
        private System.Windows.Forms.TextBox txtHT;
        private System.Windows.Forms.Label lblHT;
        private System.Windows.Forms.Label lblTVA;
        private System.Windows.Forms.Label lblTTC;
        private System.Windows.Forms.TextBox txtTVA;
        private System.Windows.Forms.TextBox txtTTC;
        private System.Windows.Forms.Button btnValid;
        private System.Windows.Forms.Label txtTitlePrinc;
        private System.Windows.Forms.TextBox txtPaiementType;
        private System.Windows.Forms.Label lblPaimentType;
        private System.Windows.Forms.TextBox txtPaiementCom;
        private System.Windows.Forms.Label lblPaimentCommentaire;
    }
}