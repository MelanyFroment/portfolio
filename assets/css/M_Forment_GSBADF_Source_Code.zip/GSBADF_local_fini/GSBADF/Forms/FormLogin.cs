﻿using GSBADF.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBADF.Forms
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private bool isValid() 
        {
            //Si le champ login, toutes les occurrences sont supprimer == la string et vide
            if (txtLogin.Text.TrimStart() == String.Empty)
            {
                //Afficher le message d'erreur
                MessageBox.Show("User name is required! Length >=5", "Error");
                return false;
            }else if (txtPassword.Text.TrimStart() == String.Empty)
            {
                MessageBox.Show("Password is required! Length >=8", "Error");
                return false;
            }
            //Et sinon les champs sont biens remplis
            return true;
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            //Si isValid
            if (isValid())
            {
                //Chaine de connection au server
                using (SqlConnection conn = new SqlConnection(Security.ConnectionString))
                {
                    //Récupération du Login et du Password sur la table tbUtilisateur du server
                    string query = "SELECT * FROM tbUtilisateur WHERE login = '" + txtLogin.Text.Trim() +
                        "'AND password = '" + txtPassword.Text.Trim() + "'";
                    //Ensemble de commandes de données et connexion de base de données qui sont utilisées pour remplir le DataSet
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    //Création de la table de données en mémoire
                    DataTable dta = new DataTable();
                    //Ajoute et/ou actualise les lignes du DataSet pour qu'elles correspondent à celles de la source de données.
                    sda.Fill(dta);
                    //Si le DataTable compte 1 ligne
                    if (dta.Rows.Count == 1)
                    {
                        Classes.Tools.CurrentUser = new Models.User()
                        {
                            Login = txtLogin.Text.Trim(),
                            Password= txtPassword.Text.Trim(),
                        };
                        this.DialogResult = DialogResult.OK;
                    }
                }
            }
        }

    }
}
