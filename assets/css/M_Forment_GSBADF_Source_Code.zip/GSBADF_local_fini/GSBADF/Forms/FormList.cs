﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBADF.Forms
{
    public partial class FormList : Form
    {
        public FormList()
        {
            InitializeComponent();
            this.dataGridView1.AutoGenerateColumns = false;
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            //Création du DataSet via la table ajout 
            Datas.DataSetGSBADFTableAdapters.tbAjoutTableAdapter tbAjoutTableAdapter = new Datas.DataSetGSBADFTableAdapters.tbAjoutTableAdapter();
            //Connexion a la table //Chaine de connexion
            tbAjoutTableAdapter.Connection = new System.Data.SqlClient.SqlConnection(Classes.Security.ConnectionString);
            //Récupération des données via le DataSet, la table Ajout
            Datas.DataSetGSBADF.tbAjoutDataTable tbAjoutRows = tbAjoutTableAdapter.GetData();
            dataGridView1.DataSource = tbAjoutRows;
        }
    }
}
